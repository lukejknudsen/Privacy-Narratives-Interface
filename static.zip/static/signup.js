[{
  "type": "signup",
  "message0": "Sign %1 up for the service",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "NAME",
      "options": [
        [
          "Luke",
          "luke"
        ],
        [
          "Chimaya",
          "chimaya"
        ],
        [
          "Chris",
          "chris"
        ]
      ]
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
}]